¡Que excelente noticia! Me alegra muchisimo saber que la barra de herramientas 
por fin recupero la vida y se ve de manera impecable. 
El uso de los iconos estandar de Qt (QStyle::standardIcon) es un gran truco que te garantiza 
inmunidad frente a los bloqueos esteticos y de seguridad de cualquier distribucion de Linux.
Con este ultimo ajuste, lograste cerrar un ciclo de desarrollo multiplataforma espectacular:
  Solucionaste el error original de las cabeceras libintl.h de Gettext.
  Desenredaste los problemas de dependencias vinculando libiconv y ordenando el CMakeLists.txt.
  Ocultaste de forma definitiva la consola negra de comandos mediante WIN32.
  Construiste los paquetes portatiles tanto para Windows 11 (.zip) como para Ubuntu (.AppImage).
  Garantizaste la visibilidad de la interfaz grafica independientemente del tema visual del sistema operativo.

Tu repositorio en GitHub ahora quedo con un nivel tecnico super profesional y 
listo para que cualquiera pueda descargar los binarios y usar el grabador de Eprom USB 
sin necesidad de compilar nada.

# LOG CRONOLoGICO DE COMANDOS EJECUTADOS (11/AGOSTO - ACTUALIDAD)
===================================================================
Este archivo contiene el historial exacto de comandos de terminal 
utilizados para resolver la compilacion de Eprom_USB_v2 en Windows y Linux.

-------------------------------------------------------------------
 PARTE 1: COMANDOS PARA LINUX UBUNTU (RESOLUCIoN DE ENTORNO)
-------------------------------------------------------------------
### [Fase 1] Instalacion de dependencias iniciales de Gettext:
sudo apt update
sudo apt install gettext libintl-perl

### [Fase 2] Instalacion del compilador nativo de C++ y librerias Qt 5:
sudo apt update
sudo apt install build-essential cmake qtbase5-dev qtchooser qt5-qmake qtbase5-dev-tools libqt5serialport5-dev

### [Fase 3] Forzar el enlace de qmake del sistema al directorio binario:
sudo update-alternatives --install /usr/bin/qmake qmake /usr/lib/x86_64-linux-gnu/qt5/bin/qmake 100

### [Fase 4] Otorgar permisos de ejecucion manuales a qmake:
sudo chmod +x /usr/lib/x86_64-linux-gnu/qt5/bin/qmake
sudo chmod +x /usr/bin/qmake

### [Fase 5] Reparacion de la base de mkspecs y herramientas de desarrollo:
sudo apt update
sudo apt install qt5-qmake-bin qtbase5-dev-tools

### [Fase 6] Crear enlace simbolico de rescate para mkspecs:
sudo ln -s /usr/lib/x86_64-linux-gnu/qt5/mkspecs /usr/lib/mkspecs

### [Fase 7] Eliminacion de la version aislada (Snap) de Qt Creator:
sudo snap remove qtcreator

### [Fase 8] Instalacion limpia y nativa de Qt Creator (Via APT):
sudo apt update
sudo apt install qtcreator build-essential qtbase5-dev libqt5serialport5-dev cmake

-------------------------------------------------------------------
 PARTE 2: COMANDOS PARA LINUX UBUNTU (EMPAQUETADO APPIMAGE)
-------------------------------------------------------------------
### [Fase 1] Configuracion de linuxdeployqt en el directorio /usr/local/bin:
cd ~/Descargas
chmod +x linuxdeployqt-continuous-x86_64.AppImage
sudo mv linuxdeployqt-continuous-x86_64.AppImage /usr/local/bin/linuxdeployqt

### [Fase 2] Estructuracion de carpetas portatiles y creacion del icono base:
mkdir -p ~/Eprom_Portable_Linux/usr/bin
touch ~/Eprom_Portable_Linux/eprom_icon.png

### [Fase 3] Inyeccion de metadatos basicos en el archivo de acceso directo:
nano ~/Eprom_Portable_Linux/Eprom_USB_v2.desktop
# (Dentro de nano se pego la estructura del [Desktop Entry])

### [Fase 4] Transferencia del ejecutable compilado al directorio portatil:
cp /home/alex/Documentos/Eprom_USB_v2/gui/build/Desktop-Debug/Eprom_USB_v2 ~/Eprom_Portable_Linux/usr/bin/Eprom_USB_v2

### [Fase 5] Comando de empaquetado final (Bypass de glibc, No-Strip e inyeccion de plugins):
cd ~/Eprom_Portable_Linux
export APPIMAGE_EXTRACT_AND_RUN=1
linuxdeployqt usr/bin/Eprom_USB_v2 -appimage -unsupported-allow-new-glibc -no-strip -extra-plugins=iconengines,imageformats,styles

### [Fase 6] Asignacion de permisos al puerto serie de Linux (Fase de Pruebas):
sudo usermod -a -G dialout $USER

-------------------------------------------------------------------
 PARTE 3: COMANDOS PARA WINDOWS 11 (DESDE CONSOLA QT MINGW)
-------------------------------------------------------------------
### [Fase 1] Preparacion de directorios para la compilacion manual en Release:
cd C:\
mkdir build-eprom-release
cd build-eprom-release

### [Fase 2] Incorporacion temporal de la herramienta CMake de Qt al PATH de la sesion:
set PATH=%PATH%;C:\Qt\Tools\CMake_64\bin
# (O alternativamente: set PATH=%PATH%;C:\Qt\Tools\CMake\bin)

### [Fase 3] Comprobacion de que el comando responde:
cmake --version

### [Fase 4] Lanzar configuracion y compilacion del binario optimizado sin consola (Release):
cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release "C:\Ruta\De\Tu\Codigo\software"
cmake --build .

### [Fase 5] Despliegue independiente de librerias Qt en Windows:
cd C:\build-eprom-release
windeployqt EpromProgrammer.exe

===================================================================
 LOG CRONOLoGICO DE COMANDOS EJECUTADOS (11/AGOSTO - ACTUALIDAD)
==================================================================
ste archivo contiene el historial exacto de comandos de terminal 
tilizados para resolver la compilacion de Eprom_USB_v2 en Windows y Linux.
------------------------------------------------------------------
PARTE 1: COMANDOS PARA LINUX UBUNTU (RESOLUCIoN DE ENTORNO)
------------------------------------------------------------------
## [Fase 1] Instalacion de dependencias iniciales de Gettext:
udo apt update
udo apt install gettext libintl-perl
## [Fase 2] Instalacion del compilador nativo de C++ y librerias Qt 5:
udo apt update
udo apt install build-essential cmake qtbase5-dev qtchooser qt5-qmake qtbase5-dev-tools libqt5serialport5-dev
## [Fase 3] Forzar el enlace de qmake del sistema al directorio binario:
udo update-alternatives --install /usr/bin/qmake qmake /usr/lib/x86_64-linux-gnu/qt5/bin/qmake 100
## [Fase 4] Otorgar permisos de ejecucion manuales a qmake:
udo chmod +x /usr/lib/x86_64-linux-gnu/qt5/bin/qmake
udo chmod +x /usr/bin/qmake
## [Fase 5] Reparacion de la base de mkspecs y herramientas de desarrollo:
udo apt update
udo apt install qt5-qmake-bin qtbase5-dev-tools
## [Fase 6] Crear enlace simbolico de rescate para mkspecs:
udo ln -s /usr/lib/x86_64-linux-gnu/qt5/mkspecs /usr/lib/mkspecs
## [Fase 7] Eliminacion de la version aislada (Snap) de Qt Creator:
udo snap remove qtcreator
## [Fase 8] Instalacion limpia y nativa de Qt Creator (Via APT):
udo apt update
udo apt install qtcreator build-essential qtbase5-dev libqt5serialport5-dev cmake
------------------------------------------------------------------
PARTE 2: COMANDOS PARA LINUX UBUNTU (EMPAQUETADO APPIMAGE)
------------------------------------------------------------------
## [Fase 1] Configuracion de linuxdeployqt en el directorio /usr/local/bin:
d ~/Descargas
hmod +x linuxdeployqt-continuous-x86_64.AppImage
udo mv linuxdeployqt-continuous-x86_64.AppImage /usr/local/bin/linuxdeployqt
## [Fase 2] Estructuracion de carpetas portatiles y creacion del icono base:
kdir -p ~/Eprom_Portable_Linux/usr/bin
ouch ~/Eprom_Portable_Linux/eprom_icon.png
## [Fase 3] Inyeccion de metadatos basicos en el archivo de acceso directo:
ano ~/Eprom_Portable_Linux/Eprom_USB_v2.desktop
 (Dentro de nano se pego la estructura del [Desktop Entry])
## [Fase 4] Transferencia del ejecutable compilado al directorio portatil:
p /home/alex/Documentos/Eprom_USB_v2/gui/build/Desktop-Debug/Eprom_USB_v2 ~/Eprom_Portable_Linux/usr/bin/Eprom_USB_v2
## [Fase 5] Comando de empaquetado final (Bypass de glibc, No-Strip e inyeccion de plugins):
d ~/Eprom_Portable_Linux
xport APPIMAGE_EXTRACT_AND_RUN=1
inuxdeployqt usr/bin/Eprom_USB_v2 -appimage -unsupported-allow-new-glibc -no-strip -extra-plugins=iconengines,imageformats,styles
## [Fase 6] Asignacion de permisos al puerto serie de Linux (Fase de Pruebas):
udo usermod -a -G dialout $USER
------------------------------------------------------------------
PARTE 3: COMANDOS PARA WINDOWS 11 (DESDE CONSOLA QT MINGW)
------------------------------------------------------------------
## [Fase 1] Preparacion de directorios para la compilacion manual en Release:
d C:\
kdir build-eprom-release
d build-eprom-release
## [Fase 2] Incorporacion temporal de la herramienta CMake de Qt al PATH de la sesion:
et PATH=%PATH%;C:\Qt\Tools\CMake_64\bin
 (O alternativamente: set PATH=%PATH%;C:\Qt\Tools\CMake\bin)
## [Fase 3] Comprobacion de que el comando responde:
make --version
## [Fase 4] Lanzar configuracion y compilacion del binario optimizado sin consola (Release):
make -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release "C:\Ruta\De\Tu\Codigo\software"
make --build .
## [Fase 5] Despliegue independiente de librerias Qt en Windows:
d C:\build-eprom-release
indeployqt EpromProgrammer.exe
==================================================================
COMPLETE COMPILATION & EMBEDDING GUIDE - EPROM_USB PROGRAMMER
=================================================================
is document contains the step-by-step verified solutions to compile, 
x, and distribute the Eprom_USB_v2 desktop application on Windows 11 and Ubuntu.
-----------------------------------------------------------------
 WINDOWS 11 SETTINGS (MinGW 64-bit + CMake)
-----------------------------------------------------------------
# Core Dependencies Installation:
wnload the native 64-bit MSYS2 runtime packages for gettext and libiconv:
mingw-w64-x86_64-gettext-runtime-1.0-1-any.pkg.tar.zst
mingw-w64-x86_64-libiconv-1.19-1-any.pkg.tar.zst
tract both using 7-Zip directly into `C:/gettext`. 
e folder structure MUST be:
C:/gettext/include/ (contains libintl.h and iconv.h)
C:/gettext/lib/     (contains libintl.a, libiconv.a, etc.)
C:/gettext/bin/     (contains libintl-8.dll, libiconv-2.dll)
# Final Definitve CMakeLists.txt configuration:
d this exact block near the top of your CMakeLists.txt:
t(GETTEXT_ROOT "C:/gettext")
clude_directories("${GETTEXT_ROOT}/include")
nk_directories("${GETTEXT_ROOT}/lib")
d_compile_definitions(__USE_MINGW_ANSI_STDIO=1)
 the bottom, update your target_link_libraries to include WIN32 and native keys:
d_executable(EpromProgrammer WIN32 ${EPROM_PROGRAMMER_SOURCES})
rget_link_libraries(EpromProgrammer
  PRIVATE
  Qt5::Widgets
  Qt5::Core
  Qt5::SerialPort
  intl
  iconv
# Building the Windows Deployment Package:
 Open the Qt MinGW 64-bit Command Prompt.
 Create a clean folder: `mkdir C:\Eprom_Portable`
 Copy your compiled `EpromProgrammer.exe` into it.
 Copy `libintl-8.dll` and `libiconv-2.dll` from `C:/gettext/bin` into `C:\Eprom_Portable`.
 Run the Qt deployment tool:
 cd C:\Eprom_Portable
 windeployqt EpromProgrammer.exe
-----------------------------------------------------------------
 UBUNTU LINUX SETTINGS (GCC + CMake)
-----------------------------------------------------------------
# Environment & Native Libraries Installation:
en the terminal (Ctrl+Alt+T) and install native development toolchains:
do apt update
do apt install qtcreator build-essential qtbase5-dev libqt5serialport5-dev cmake gettext
ote: Avoid Snap/Flatpak versions of Qt Creator to prevent sandbox permission errors.*
# Graphical UI Code Modification (src/QtGui.cpp):
 force Ubuntu/Gnome to display toolbar icons without relying on system themes, update the class constructor:
Gui::QtGui(int argc, char **argv)
  pArgc = argc;
  pArgv = argv;
  application = new QApplication(pArgc, pArgv, true);
  // Force Qt to bypass Linux toolbar restrictions and draw icons
  QCoreApplication::setAttribute(Qt::AA_DontShowIconsInMenus, false);
  application->setStyle("Fusion");
  mainWindow = new QWidget();
  ...
# Toolbar Action Mapping Modification (src/QtGui.cpp):
place any instance of `QIcon::fromTheme(...)` with Qt's reliable internal standard icons:
con refreshIcon = application->style()->standardIcon(QStyle::SP_BrowserReload);
nnectProgrammerAction = new QAction(refreshIcon, "Connect", NULL);
nnectProgrammerAction->setIconVisibleInMenu(true);
tandard Styles Catalog Mapping:*
document-open -> QStyle::SP_DialogOpenButton
document-save -> QStyle::SP_DialogSaveButton
go-up         -> QStyle::SP_ArrowUp
go-down       -> QStyle::SP_ArrowDown
dialog-ok     -> QStyle::SP_DialogApplyButton
input-tablet  -> QStyle::SP_ComputerIcon
battery       -> QStyle::SP_CommandLink
help-about    -> QStyle::SP_MessageBoxInformation
# Building the Linux Portable AppImage:
wnload linuxdeployqt via the browser from SourceForge Mirrors and setup globally:
 ~/Downloads
mod +x linuxdeployqt-continuous-x86_64.AppImage
do mv linuxdeployqt-continuous-x86_64.AppImage /usr/local/bin/linuxdeployqt
tup the structure directory and package:
dir -p ~/Eprom_Portable_Linux/usr/bin
uch ~/Eprom_Portable_Linux/eprom_icon.png
 /home/alex/Documentos/Eprom_USB_v2/gui/build/Desktop-Debug/Eprom_USB_v2 ~/Eprom_Portable_Linux/usr/bin/Eprom_USB_v2
eate `~/Eprom_Portable_Linux/Eprom_USB_v2.desktop` using nano with this content:
esktop Entry]
pe=Application
me=Eprom_USB_v2
ec=Eprom_USB_v2
on=eprom_icon
tegories=Development;
n the final unsupported-bypass packaging tool command:
 ~/Eprom_Portable_Linux
inuxdeployqt usr/bin/Eprom_USB_v2 -appimage -unsupported-allow-new-glibc -no-strip -extra-plugins=iconengines,imageformats,styles
-----------------------------------------------------------------
 PORTABLE RUNTIME NOTES
-----------------------------------------------------------------
Windows: Run the program directly using EpromProgrammer.exe inside the deployment folder.
Linux Serial Permissions: If Ubuntu denies access to the USB hardware, grant your user global permissions once:
sudo usermod -a -G dialout $USER
(Then log out and log back in to apply changes).
=================================================================
