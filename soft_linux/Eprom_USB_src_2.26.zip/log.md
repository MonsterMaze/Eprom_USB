# LOG CRONOLoGICO DE COMANDOS EJECUTADOS (11/AGOSTO - ACTUALIDAD)
===================================================================
Este archivo contiene el historial exacto de comandos de terminal 
utilizados para resolver la compilacion de Eprom_USB_v2 en Windows y Linux.

-------------------------------------------------------------------
 PARTE 1: COMANDOS PARA LINUX UBUNTU (RESOLUCIoN DE ENTORNO)
-------------------------------------------------------------------
### [Fase 1] Instalacion de dependencias iniciales de Gettext:
sudo apt update
sudo apt install gettext libintl-perl

### [Fase 2] Instalacion del compilador nativo de C++ y librerias Qt 5:
sudo apt update
sudo apt install build-essential cmake qtbase5-dev qtchooser qt5-qmake qtbase5-dev-tools libqt5serialport5-dev

### [Fase 3] Forzar el enlace de qmake del sistema al directorio binario:
sudo update-alternatives --install /usr/bin/qmake qmake /usr/lib/x86_64-linux-gnu/qt5/bin/qmake 100

### [Fase 4] Otorgar permisos de ejecucion manuales a qmake:
sudo chmod +x /usr/lib/x86_64-linux-gnu/qt5/bin/qmake
sudo chmod +x /usr/bin/qmake

### [Fase 5] Reparacion de la base de mkspecs y herramientas de desarrollo:
sudo apt update
sudo apt install qt5-qmake-bin qtbase5-dev-tools

### [Fase 6] Crear enlace simbolico de rescate para mkspecs:
sudo ln -s /usr/lib/x86_64-linux-gnu/qt5/mkspecs /usr/lib/mkspecs

### [Fase 7] Eliminacion de la version aislada (Snap) de Qt Creator:
sudo snap remove qtcreator

### [Fase 8] Instalacion limpia y nativa de Qt Creator (Via APT):
sudo apt update
sudo apt install qtcreator build-essential qtbase5-dev libqt5serialport5-dev cmake

-------------------------------------------------------------------
 PARTE 2: COMANDOS PARA LINUX UBUNTU (EMPAQUETADO APPIMAGE)
-------------------------------------------------------------------
### [Fase 1] Configuracion de linuxdeployqt en el directorio /usr/local/bin:
cd ~/Descargas
chmod +x linuxdeployqt-continuous-x86_64.AppImage
sudo mv linuxdeployqt-continuous-x86_64.AppImage /usr/local/bin/linuxdeployqt

### [Fase 2] Estructuracion de carpetas portatiles y creacion del icono base:
mkdir -p ~/Eprom_Portable_Linux/usr/bin
touch ~/Eprom_Portable_Linux/eprom_icon.png

### [Fase 3] Inyeccion de metadatos basicos en el archivo de acceso directo:
nano ~/Eprom_Portable_Linux/Eprom_USB_v2.desktop
# (Dentro de nano se pego la estructura del [Desktop Entry])

### [Fase 4] Transferencia del ejecutable compilado al directorio portatil:
cp /home/alex/Documentos/Eprom_USB_v2/gui/build/Desktop-Debug/Eprom_USB_v2 ~/Eprom_Portable_Linux/usr/bin/Eprom_USB_v2

### [Fase 5] Comando de empaquetado final (Bypass de glibc, No-Strip e inyeccion de plugins):
cd ~/Eprom_Portable_Linux
export APPIMAGE_EXTRACT_AND_RUN=1
linuxdeployqt usr/bin/Eprom_USB_v2 -appimage -unsupported-allow-new-glibc -no-strip -extra-plugins=iconengines,imageformats,styles

### [Fase 6] Asignacion de permisos al puerto serie de Linux (Fase de Pruebas):
sudo usermod -a -G dialout $USER

-------------------------------------------------------------------
 PARTE 3: COMANDOS PARA WINDOWS 11 (DESDE CONSOLA QT MINGW)
-------------------------------------------------------------------
### [Fase 1] Preparacion de directorios para la compilacion manual en Release:
cd C:\
mkdir build-eprom-release
cd build-eprom-release

### [Fase 2] Incorporacion temporal de la herramienta CMake de Qt al PATH de la sesion:
set PATH=%PATH%;C:\Qt\Tools\CMake_64\bin
# (O alternativamente: set PATH=%PATH%;C:\Qt\Tools\CMake\bin)

### [Fase 3] Comprobacion de que el comando responde:
cmake --version

### [Fase 4] Lanzar configuracion y compilacion del binario optimizado sin consola (Release):
cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release "C:\Ruta\De\Tu\Codigo\software"
cmake --build .

### [Fase 5] Despliegue independiente de librerias Qt en Windows:
cd C:\build-eprom-release
windeployqt EpromProgrammer.exe

===================================================================
