#include "customwindow.h"

CustomWindow::CustomWindow(const QString &title, QWidget *parent) : QWidget(parent) {
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    QVBoxLayout *windowLayout = new QVBoxLayout(this);
    windowLayout->setContentsMargins(1, 1, 1, 1);
    windowLayout->setSpacing(0);

    setStyleSheet("QWidget#BaseWindow { background-color: #2d2d2d; border: 1px solid #444444; border-radius: 6px; }");
    setObjectName("BaseWindow");

    QWidget *titleBar = new QWidget(this);
    titleBar->setStyleSheet("background-color: #1e1e1e; border-bottom: 1px solid #333333; border-top-left-radius: 5px; border-top-right-radius: 5px;");
    titleBar->setFixedHeight(32);

    QHBoxLayout *titleLayout = new QHBoxLayout(titleBar);
    titleLayout->setContentsMargins(10, 0, 10, 0);

    QLabel *iconLabel = new QLabel(titleBar);
    iconLabel->setPixmap(QIcon(":/icons/Eprom_USB.png").pixmap(18, 18));
    iconLabel->setStyleSheet("border: none; background: transparent;");
    titleLayout->addWidget(iconLabel);

    // En src/customwindow.cpp
    QLabel *titleLabel = new QLabel(title, titleBar);
    // 🟩 Agrandamos la letra a 13px (puedes usar 14px si la quieres aun mas grande)
    titleLabel->setStyleSheet("color: #ffffff; font-weight: bold; font-size: 13px; border: none; background: transparent; margin-left: 5px;");
    titleLayout->addWidget(titleLabel);
    titleLayout->addStretch();

    QPushButton *closeButton = new QPushButton("✕", titleBar);
    closeButton->setFixedSize(24, 24);
    closeButton->setStyleSheet("QPushButton { color: #aaaaaa; background: transparent; border: none; font-size: 11px; font-weight: bold; }"
                               "QPushButton:hover { color: #ffffff; background-color: #cc3333; border-radius: 3px; }");
    connect(closeButton, &QPushButton::clicked, this, &QWidget::close);
    titleLayout->addWidget(closeButton);

    windowLayout->addWidget(titleBar);

    // === BUSCA ESTAS LiNEAS AL FINAL DE TU CONSTRUCTOR EN customwindow.cpp ===
    contentWidget = new QWidget(this);

    // 🟩 SOLUCIoN: Quitamos el background-color forzado que rompia tus textos.
    // Solo dejamos que sea transparente para que herede el hermoso tema oscuro nativo de tu Ubuntu.
    contentWidget->setStyleSheet("QWidget#ContentBase { background: transparent; border: none; }");
    contentWidget->setObjectName("ContentBase");

    windowLayout->addWidget(contentWidget);
}

QVBoxLayout *CustomWindow::getContentLayout() {
    if (!contentWidget->layout()) {
        QVBoxLayout *layout = new QVBoxLayout(contentWidget);
        layout->setContentsMargins(15, 15, 15, 15);
        return layout;
    }
    return qobject_cast<QVBoxLayout*>(contentWidget->layout());
}

void CustomWindow::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton && event->pos().y() < 32) {
        dragPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void CustomWindow::mouseMoveEvent(QMouseEvent *event) {
    if (event->buttons() & Qt::LeftButton && event->pos().y() < 64) {
        move(event->globalPos() - dragPosition);
        event->accept();
    }
}
