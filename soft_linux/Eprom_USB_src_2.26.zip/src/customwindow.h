#ifndef CUSTOMWINDOW_H
#define CUSTOMWINDOW_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QIcon>
#include <QMouseEvent>
#include <QPoint>

class CustomWindow : public QWidget {
    Q_OBJECT
public:
    CustomWindow(const QString &title, QWidget *parent = nullptr);
    QVBoxLayout *getContentLayout();

protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

private:
    QWidget *contentWidget;
    QPoint dragPosition;
};

#endif // CUSTOMWINDOW_H
