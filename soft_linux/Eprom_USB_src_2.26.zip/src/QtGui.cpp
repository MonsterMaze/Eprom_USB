/**
 * 
 * Eprom Programmer
 * 
 * Copyright (C) 2021-2023 Ciprian Stingu
 * ciprian stingu at gmail dot com
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA
 * or see <http://www.gnu.org/licenses/>
 * 
 */
//----------------------------------------------------------------------
#include "QtGui.h"
#include <libintl.h>
#include <string.h>
#include <math.h>
//#include "QtIcons.h"
#include <QDebug>
#include <QLoggingCategory>
#include "customwindow.h"
//----------------------------------------------------------------------

QtGui::QtGui(int argc, char **argv)
{
    pArgc = argc;
    pArgv = argv;

 // Configuracion estatica del estilo antes de crear la app
    QApplication::setStyle("Fusion");

    application = new QApplication(pArgc, pArgv, true);

    // === CONFIGURACIoN DE IDENTIDAD ===
    application->setApplicationName("Eprom_USB");
    application->setApplicationDisplayName("Eprom_USB");
    application->setStyle("Fusion");
    application->setDesktopFileName("Eprom_USB");

//  ESTILO GLOBAL OBLIGATORIO PARA ALERTAS, ERRORES Y PREGUNTAS (QMessageBox)
    application->setStyleSheet(
        "QMessageBox { background-color: #2d2d2d; border: 1px solid #555555; }"
        "QMessageBox QLabel { color: #ffffff; font-size: 13px; padding: 10px; }"
        "QMessageBox QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; min-width: 75px; }"
        "QMessageBox QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }"
        );

// === CONFIGURACIoN DE ICONOS ===
    QIcon icon(":/icons/Eprom_USB.png");
    if (icon.isNull()) {
        qDebug() << "ERROR: No se encontro el icono en los recursos!";
    } else {
        qDebug() << "Icon Eprom_USB.png cargado correctamente";
    }
    application->setWindowIcon(icon);

// === FILTRADO SEGURO DE LOGS ===
    QLoggingCategory::setFilterRules("qt.qpa.wayland.debug=false\n"
                                     "qt.qpa.wayland=false\n"
                                     "qt.qpa.screen.debug=false\n"
                                     "qt.core.socketnotifier=false");

// Forzar atributos de menu
    QCoreApplication::setAttribute(Qt::AA_DontShowIconsInMenus, false);

// Generamos el string del titulo completo (Tu logica con macros)
    QString MainWindowTitle = MAKE_STR(APP_NAME);
    MainWindowTitle.append(" - v");
    MainWindowTitle.append(APP_VERSION);

//  INSTANCIAMOS LA VENTANA PERSONALIZADA UNIVERSAL (Eliminada la vieja QWidget)
    CustomWindow *customMain = new CustomWindow(MainWindowTitle);
    customMain->resize(700, 640);

// Vinculamos al puntero original de tu clase para mantener la compatibilidad
    mainWindow = customMain;

// Inicializamos tus widgets del programa (Solo una vez)
    mainToolbar = CreateToolbar();
    mainTabs = new QTabWidget();
    CreateDataTab(mainTabs);
    CreateDeviceTab(mainTabs);
    mainStatusBar = new QStatusBar();

// OBTENEMOS EL LAYOUT DE CONTENIDO DE LA VENTANA PERSONALIZADA
// Ponemos los margenes en 0 para que la toolbar pegue bien arriba
    QVBoxLayout *MainLayout = customMain->getContentLayout();
    MainLayout->setContentsMargins(0, 0, 0, 0);
    MainLayout->setSpacing(5);

// Añadimos tus elementos reales de trabajo a la estructura
    MainLayout->addWidget(mainToolbar);
    MainLayout->addWidget(mainTabs);
    MainLayout->addWidget(mainStatusBar);

// Centrar en pantalla
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    int x = (screenGeometry.width() - mainWindow->width()) / 2;
    int y = (screenGeometry.height() - mainWindow->height()) / 2;
    mainWindow->move(x, y);

// Inicializacion del hardware de comunicacion
    serialPort = new QSerialPort();
    selectedEprom = EPROM_TYPE::NONE;
    arduinoIO = nullptr;

    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

QtGui::~QtGui()
{	
    CloseMainWindow();
}
//----------------------------------------------------------------------

void QtGui::Run(void)
{
    mainWindow->show();
    application->exec();
}
//----------------------------------------------------------------------

void QtGui::CloseMainWindow(void)
{
    CloseSerialPort();
}
//----------------------------------------------------------------------

QToolBar *QtGui::CreateToolbar(void)
{
    QToolBar *mainToobar = new QToolBar();

//  ESTILO INTEGRADO PARA LA TOOLBAR (Modo Oscuro Profesional)
    mainToobar->setStyleSheet(
// Margen de los botones
        "QToolButton { padding-left: 6px; padding-right: 6px; border: none; border-radius: 4px; background: transparent; }"
// Al pasar el mouse por encima: fondo gris sutil, NO blanco
        "QToolButton:hover { background-color: #444444; }"
// Al hacer clic: fondo un poco mas oscuro
        "QToolButton:pressed { background-color: #555555; }"
// Estilo de la linea divisoria vertical (Separadores)
        "QToolBar::separator { background-color: #444444; width: 1px; margin-top: 4px; margin-bottom: 4px; }"
// Linea divisoria inferior horizontal que delimita la toolbar hacia abajo
        "QToolBar { background-color: transparent; border-bottom: 1px solid #3a3a3a; spacing: 5px; padding: 4px; }"
        );

// 1. Boton CONNECT (view-refresh -> SP_BrowserReload)
    QIcon refreshIcon(":/icons/connect.png");

    connectProgrammerAction = new QAction(refreshIcon, "Connect", NULL);
    connect(connectProgrammerAction, SIGNAL(triggered()), this, SLOT(ShowConnectSlot()));
    connectProgrammerAction->setIconVisibleInMenu(true);
    mainToobar->addAction(connectProgrammerAction);

    mainToobar->addSeparator();

// 2. Boton OPEN FILE (document-open -> SP_DialogOpenButton)
    QIcon openIcon(":/icons/open-folder.png");

    openFileAction = new QAction(openIcon, "Open File", NULL);
    connect(openFileAction, SIGNAL(triggered()), this, SLOT(FileOpenSlot()));
    openFileAction->setEnabled(false);
    openFileAction->setIconVisibleInMenu(true);
    mainToobar->addAction(openFileAction);

// 3. Boton SAVE FILE (document-save -> SP_DialogSaveButton)
    QIcon saveIcon(":/icons/save-file.png");

    saveFileAction = new QAction(saveIcon, "Save File", NULL);
    connect(saveFileAction, SIGNAL(triggered()), this, SLOT(FileSaveSlot()));
    saveFileAction->setEnabled(false);
    saveFileAction->setIconVisibleInMenu(true);
    mainToobar->addAction(saveFileAction);

    mainToobar->addSeparator();

// 4. Boton READ DEVICE (go-up -> SP_ArrowUp)
    QIcon readIcon(":/icons/read_eprom.png");

    readDeviceAction = new QAction(readIcon, "Read device", NULL);
    connect(readDeviceAction, SIGNAL(triggered()), this, SLOT(ReadEpromSlot()));
    readDeviceAction->setEnabled(false);
    readDeviceAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(readDeviceAction);

// 5. Boton WRITE DEVICE (go-down -> SP_ArrowDown)
    QIcon writeIcon(":/icons/write_eprom.png");

    writeDeviceAction = new QAction(writeIcon, "Write device", NULL);
    connect(writeDeviceAction, SIGNAL(triggered()), this, SLOT(WriteEpromSlot()));
    writeDeviceAction->setEnabled(false);
    writeDeviceAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(writeDeviceAction);

// 6. Boton VERIFY (dialog-ok -> SP_DialogApplyButton)
    QIcon verifyIcon(":/icons/verify_eprom.png");

    verifyDataAction = new QAction(verifyIcon, "Verify", NULL);
    connect(verifyDataAction, SIGNAL(triggered()), this, SLOT(VerifyDataSlot()));
    verifyDataAction->setEnabled(false);
    verifyDataAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(verifyDataAction);

    mainToobar->addSeparator();

// 7. Boton HARDWARE TEST (input-tablet -> SP_ComputerIcon)
    QIcon hwTestIcon(":/icons/testing.png");

    hardwareTestAction = new QAction(hwTestIcon, "Hardware Test", NULL);
    connect(hardwareTestAction, SIGNAL(triggered()), this, SLOT(HardwareTestSlot()));
    hardwareTestAction->setEnabled(false);
    hardwareTestAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(hardwareTestAction);

// 8. Boton READ VOLTAGE (battery -> SP_ArrowLeft)
    QIcon voltageIcon(":/icons/read_voltages.png");

    readVoltageAction = new QAction(voltageIcon, "Read Voltage", NULL);
    connect(readVoltageAction, SIGNAL(triggered()), this, SLOT(ShowVoltageSlot()));
    readVoltageAction->setEnabled(false);
    readVoltageAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(readVoltageAction);

    mainToobar->addSeparator();

// 9. Boton INFO (help-about -> SP_MessageBoxInformation)
    QIcon helpIcon(":/icons/info-144.png");

    showHelpAction = new QAction(helpIcon, "Info", NULL);
    connect(showHelpAction, SIGNAL(triggered()), this, SLOT(ShowHelpSlot()));
    showHelpAction->setIconVisibleInMenu(true); // Forzar visibilidad
    mainToobar->addAction(showHelpAction);

    mainToobar->addSeparator();

    QWidgetAction* progressBarAct = new QWidgetAction(this);
    mainProgressBar = new QProgressBar();
    progressBarAct->setDefaultWidget(mainProgressBar);
    mainToobar->addAction(progressBarAct);

    return mainToobar;
}
//----------------------------------------------------------------------

void QtGui::CreateDataTab(QTabWidget *mainTabs)
{
//log box
    logBox = new QTextEdit();
    logBox->setReadOnly(true);
    logBox->setLineWrapMode(QTextEdit::NoWrap);
    logBox->setAcceptRichText(false);
    logBox->setFontFamily("monospace");
    logBox->setFontPointSize(10);
    
    QVBoxLayout *dataTabLayout = new QVBoxLayout();
    dataTabLayout->addWidget(logBox);
    
    dataTab = new QWidget;
    dataTab->setLayout(dataTabLayout);
    
    mainTabs->addTab(dataTab, "Data");
}
//----------------------------------------------------------------------

void QtGui::CreateDeviceTab(QTabWidget *mainTabs)
{
    extern EPROM EpromsList[];
	extern size_t EpromsListSize;
    char tmpStr[1024];
    
    QLabel *deviceTypeComboLabel = new QLabel("Eprom Type");
    epromTypeCombo = new QComboBox();
    for(size_t i = 0; i < EpromsListSize; i++)
    {
        if(EpromsList[i].EpromType == EPROM_TYPE::LAST) {
            epromTypeCombo->insertSeparator(0xFFFF);
        }
        else
        {
            strncpy(tmpStr, EpromsList[i].EpromName, 1023);
            epromTypeCombo->addItem(tmpStr);
        }
    }
    epromTypeCombo->setCurrentIndex(selectedEprom);
    connect(epromTypeCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(ChangeEpromTypeSlot(int)));
    epromTypeCombo->setEnabled(false);
    epromTypeCombo->setFixedWidth(200);
    
    QHBoxLayout *firstRowLayout = new QHBoxLayout();
    firstRowLayout->setAlignment(Qt::AlignLeft);
    firstRowLayout->addWidget(deviceTypeComboLabel);
    firstRowLayout->addSpacing(10);
    firstRowLayout->addWidget(epromTypeCombo);
    
    QLabel *deviceInfoLabelLabel = new QLabel("Info: ");
    epromInfoLabel = new QLabel();
    sprintf(tmpStr, "%s, VCC: %.2fV, VPP: %.2fV, %srite optimization available", 
            EpromsList[selectedEprom].EpromDescription, EpromsList[selectedEprom].ProgrammingVccVoltage[0], EpromsList[selectedEprom].VppVoltage[0], 
            WriteOptimizationAvailable(EpromsList[selectedEprom]) ? "W" : "No w");
    epromInfoLabel->setText(tmpStr);
    QHBoxLayout *secondRowLayout = new QHBoxLayout();
    secondRowLayout->setAlignment(Qt::AlignLeft);
    secondRowLayout->addWidget(deviceInfoLabelLabel);
    secondRowLayout->addSpacing(10);
    secondRowLayout->addWidget(epromInfoLabel);
    
    QLabel *progAlgoComboLabel = new QLabel("Programming algorithm");
    progAlgoCombo = new QComboBox();
    progAlgoCombo->setCurrentIndex(0);
    connect(progAlgoCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(ChangeProgrammingAlgorithmSlot(int)));
    progAlgoCombo->setEnabled(false);
    progAlgoCombo->setFixedWidth(200);
    
    QHBoxLayout *thirdRowLayout = new QHBoxLayout();
    thirdRowLayout->setAlignment(Qt::AlignLeft);
    thirdRowLayout->addWidget(progAlgoComboLabel);
    thirdRowLayout->addSpacing(10);
    thirdRowLayout->addWidget(progAlgoCombo);
    
    QLabel *labelVpp = new QLabel("VPP");
    entryVpp = new QLineEdit();
    entryVpp->setMaxLength(5);
    entryVpp->setFixedWidth(50);
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].VppVoltage[0]);
    entryVpp->setText(tmpStr);
    entryVpp->setEnabled(false);
    QLabel *labelVppVolts = new QLabel("V - Please check the data sheet before programming!");
    QHBoxLayout *layoutVpp = new QHBoxLayout();
    layoutVpp->setAlignment(Qt::AlignRight);
    layoutVpp->addWidget(labelVpp);
    layoutVpp->addSpacing(45);
    layoutVpp->addWidget(entryVpp);
    layoutVpp->addSpacing(2);
    layoutVpp->addWidget(labelVppVolts);
    QFrame *frameVpp = new QFrame();
    frameVpp->setFrameShadow(QFrame::Plain);
    frameVpp->setFrameShape(QFrame::NoFrame);
    frameVpp->setFixedWidth(510);
    frameVpp->setLayout(layoutVpp);
    
    QLabel *labelProgVcc = new QLabel("Programming VCC");
    entryProgVcc = new QLineEdit();
    entryProgVcc->setMaxLength(4);
    entryProgVcc->setFixedWidth(50);
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].ProgrammingVccVoltage[0]);
    entryProgVcc->setText(tmpStr);
    entryProgVcc->setEnabled(false);
    QLabel *labelProgVccVolts = new QLabel("V - Please check the data sheet before programming!");
    QHBoxLayout *layoutProgVcc = new QHBoxLayout();
    layoutProgVcc->setAlignment(Qt::AlignRight);
    layoutProgVcc->addWidget(labelProgVcc);
    layoutProgVcc->addSpacing(5);
    layoutProgVcc->addWidget(entryProgVcc);
    layoutProgVcc->addSpacing(2);
    layoutProgVcc->addWidget(labelProgVccVolts);
    QFrame *frameProgVcc = new QFrame();
    frameProgVcc->setFrameShadow(QFrame::Plain);
    frameProgVcc->setFrameShape(QFrame::NoFrame);
    frameProgVcc->setFixedWidth(510);
    frameProgVcc->setLayout(layoutProgVcc);

    QGridLayout *optionsLayout = new QGridLayout();
    optionsLayout->setAlignment(Qt::AlignTop);
    optionsLayout->addWidget(frameVpp, 0, 0, 1, 2);
    optionsLayout->addWidget(frameProgVcc, 1, 0, 1, 2);
    
    QVBoxLayout *deviceTabLayout = new QVBoxLayout();
    deviceTabLayout->setContentsMargins(25, 25, 25, 25);
    deviceTabLayout->setAlignment(Qt::AlignTop);
    deviceTabLayout->addLayout(firstRowLayout);
    deviceTabLayout->addLayout(secondRowLayout);
    deviceTabLayout->addLayout(thirdRowLayout);
    deviceTabLayout->addLayout(optionsLayout);

    deviceTab = new QWidget;
    deviceTab->setLayout(deviceTabLayout);
    
    mainTabs->addTab(deviceTab, "Device");
}
//----------------------------------------------------------------------

void QtGui::ShowConnectSlot(void)
{
// logica de inicio serialPort

    QLabel *serialPortLabel = new QLabel("Available serial ports");
    serialPortLabel->setAlignment(Qt::AlignHCenter);

// Forzar texto blanco para que se lea perfecto arriba de la lista
    serialPortLabel->setStyleSheet("color: #ffffff; font-weight: bold;");
    connectionList = new QListWidget();

//  ESTILO MODERNO PARA LA LISTA DE PUERTOS SERIALES
    connectionList->setStyleSheet(
// Fondo gris oscuro integrado, texto blanco y bordes redondeados sutiles
        "QListWidget { background-color: #1e1e1e; color: #ffffff; border: 1px solid #444444; border-radius: 4px; padding: 5px; }"
// Estilo de cada elemento de la lista (puerto)
        "QListWidget::item { padding: 4px; border-radius: 2px; }"
// Al pasar el mouse por encima de un puerto (hover)
        "QListWidget::item:hover { background-color: #333333; }"
// Al hacer clic y seleccionar un puerto serial
        "QListWidget::item:selected { background-color: #0056b3; color: white; font-weight: bold; }"
        );

    RefreshSerialPortSlot();

    QVBoxLayout *connectLayout = new QVBoxLayout();
    connectLayout->setAlignment(Qt::AlignTop);
    connectLayout->setContentsMargins(25, 5, 25, 20);
    connectLayout->addSpacing(5);
    connectLayout->addWidget(serialPortLabel);
    connectLayout->addSpacing(5);
    connectLayout->addWidget(connectionList);

    QPushButton *connectButton = new QPushButton();
    connectButton->setText("Connect");

//  Estilo oscuro unificado
    connectButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                                 "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(connectButton, SIGNAL(clicked()), this, SLOT(ConnectToSerialPortSlot()));

    QPushButton *refreshButton = new QPushButton();
    refreshButton->setText("Refresh");
    refreshButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                                 "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(refreshButton, SIGNAL(clicked()), this, SLOT(RefreshSerialPortSlot()));

    QPushButton *closeButton = new QPushButton();
    closeButton->setText("Close");
    closeButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                               "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(closeButton, SIGNAL(clicked()), this, SLOT(CloseConnectWindowSlot()));

    QHBoxLayout *connectButtonsLayout = new QHBoxLayout();
    connectButtonsLayout->setContentsMargins(25, 15, 25, 0);
    connectButtonsLayout->addWidget(connectButton);
    connectButtonsLayout->addSpacing(20);
    connectButtonsLayout->addWidget(refreshButton);
    connectButtonsLayout->addSpacing(20);
    connectButtonsLayout->addWidget(closeButton);

    connectLayout->addLayout(connectButtonsLayout);

// Cambiamos el QWidget tradicional por CustomWindow pasandole el titulo
    CustomWindow *customConnect = new CustomWindow(gettext("Connect"));
    customConnect->resize(280, 240);

// Sincronizamos con tu puntero de control original
    connectWindow = customConnect;

// Obtenemos el layout de la zona transparente e inyectamos los elementos debajo del titulo
    QVBoxLayout *innerLayout = customConnect->getContentLayout();
    innerLayout->addLayout(connectLayout);

// Mover al centro de la pantalla
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    int x = (screenGeometry.width() - connectWindow->width()) / 2;
    int y = (screenGeometry.height() - connectWindow->height()) / 2;
    connectWindow->move(x, y);

    DisableButtons();

// Mostrar la ventana con su barra custom e icono definitivo
    customConnect->show();
}
//----------------------------------------------------------------------

void QtGui::RefreshSerialPortSlot(void)
{
    connectionList->clear();
    const auto infos = QSerialPortInfo::availablePorts();
    for(const QSerialPortInfo &info : infos)
    {
        QListWidgetItem *item = new QListWidgetItem(info.portName(), connectionList);
        item->setData(Qt::UserRole, info.systemLocation());
        if(info.isBusy())
        {
            item->setText(info.portName() + " (Busy)");
            item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
        }
    }
}
//----------------------------------------------------------------------

void QtGui::ConnectToSerialPortSlot(void)
{
    QListWidgetItem* item = connectionList->currentItem();

    if(item == nullptr)
    {
// REEMPLAZO MODERNO Y OSCURO:
        ShowCustomAlert(QMessageBox::Critical, MAKE_STR(APP_NAME), "Select a serial port!", QMessageBox::Close);
        return;
    }

    if(!(item->flags() & Qt::ItemIsSelectable))
    {
//  REEMPLAZO MODERNO Y OSCURO:
        ShowCustomAlert(QMessageBox::Critical, MAKE_STR(APP_NAME), "Port is busy!", QMessageBox::Close);
        return;
    }
    
    CloseSerialPort();
    LogMessage(QString("Connecting to %1...\n").arg(item->data(Qt::UserRole).toString()));
    OpenSerialPort(item->data(Qt::UserRole).toString());
}
//----------------------------------------------------------------------

void QtGui::OpenSerialPort(QString path)
{
    serialPort->setPortName(path);
    serialPort->setBaudRate(QSerialPort::Baud115200);

    if(serialPort->open(QIODevice::ReadWrite))
    {
        int counter = 0;
        while(!serialPort->waitForReadyRead(1) && ++counter < 5000);
        if(serialPort->bytesAvailable())
        {
            QByteArray readData;
            
            while(!serialPort->atEnd()) {
                readData += serialPort->readAll();
            }
            
            serialPort->clear();
            
            if(readData.indexOf(PROGRAMMER_NAME, 0) != -1)
            {
                LogMessage("Connected to eprom programmer.\n");

                arduinoIO = new ArduinoIO(serialPort);

                serialOperationStartConnection = QObject::connect(arduinoIO, SIGNAL(SerialOperationStartSignal()), this, SLOT(UpdateCursorOnSerialOperationStartSlot()));
                serialOperationErrorConnection = QObject::connect(arduinoIO, SIGNAL(SerialOperationErrorSignal(const char *)), this, SLOT(ShowMessageOnSerialOperationErrorSlot(const char *)));
                serialOperationCompleteConnection = QObject::connect(arduinoIO, SIGNAL(SerialOperationCompleteSignal()), this, SLOT(UpdateCursorOnSerialOperationCompleteSlot()));

                ResetVariables();
                
                CloseConnectWindowSlot();
                
                connectProgrammerAction->setText("Disconnect");
                UpdateButtonsStatus();
                return;
            }
        }
        LogMessage("Eprom programmer not found.\n");
        CloseSerialPort();
    } 
    else {
 // REEMPLAZO PARA ERRORES DINaMICOS DEL PUERTO SERIAL:
        ShowCustomAlert(QMessageBox::Critical, "Error", serialPort->errorString(), QMessageBox::Close);
    }
}
//----------------------------------------------------------------------

void QtGui::UpdateButtonsStatus(void)
{
    bool enabled = serialPort->isOpen();
    
    connectProgrammerAction->setEnabled(true);
    openFileAction->setEnabled(enabled && selectedEprom != EPROM_TYPE::NONE);
    saveFileAction->setEnabled(enabled && epromRead && selectedEprom != EPROM_TYPE::NONE);
    readDeviceAction->setEnabled(enabled && selectedEprom != EPROM_TYPE::NONE);
    writeDeviceAction->setEnabled(enabled && fileLoaded && selectedEprom != EPROM_TYPE::NONE);
    verifyDataAction->setEnabled(enabled && (epromWritten || fileLoaded) && selectedEprom != EPROM_TYPE::NONE);
    //stopRWDeviceAction->setEnabled(enabled);
    hardwareTestAction->setEnabled(enabled);
    readVoltageAction->setEnabled(enabled);
    epromTypeCombo->setEnabled(enabled);
    progAlgoCombo->setEnabled(enabled && selectedEprom != EPROM_TYPE::NONE);
    entryVpp->setEnabled(enabled && selectedEprom != EPROM_TYPE::NONE);
    entryProgVcc->setEnabled(enabled && selectedEprom != EPROM_TYPE::NONE);
    showHelpAction->setEnabled(true);
}
//----------------------------------------------------------------------

void QtGui::DisableButtons(void)
{
    connectProgrammerAction->setEnabled(false);
    openFileAction->setEnabled(false);
    saveFileAction->setEnabled(false);
    readDeviceAction->setEnabled(false);
    writeDeviceAction->setEnabled(false);
    verifyDataAction->setEnabled(false);
    //stopRWDeviceAction->setEnabled(enabled);
    hardwareTestAction->setEnabled(false);
    readVoltageAction->setEnabled(false);
    epromTypeCombo->setEnabled(false);
    progAlgoCombo->setEnabled(false);
    entryVpp->setEnabled(false);
    entryProgVcc->setEnabled(false);
    showHelpAction->setEnabled(false);
}
//----------------------------------------------------------------------

void QtGui::CloseSerialPort(void)
{
    if(serialPort->isOpen())
    {
        QObject::disconnect(serialOperationStartConnection);
        QObject::disconnect(serialOperationErrorConnection);
        QObject::disconnect(serialOperationCompleteConnection);

        if(arduinoIO != nullptr)
        {
            delete arduinoIO;
            arduinoIO = nullptr;
        }
        
        serialPort->close();
        LogMessage("Disconnected from eprom programmer.\n");
        epromTypeCombo->setCurrentIndex(0);
        ResetVariables();
        UpdateButtonsStatus();
    }
}
//----------------------------------------------------------------------

void QtGui::CloseConnectWindowSlot(void)
{
    connectWindow->close();
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

void QtGui::ChangeEpromTypeSlot(int _index)
{
    extern EPROM EpromsList[];
    char tmpStr[1024];
    
    ResetVariables();
    
    selectedEprom = (EPROM_TYPE)_index;
    
    progAlgoCombo->clear();
    for(size_t i = 0; i < PROGRAMMING_ALGORITHMS; i++)
    {
        if(EpromsList[selectedEprom].ProgrammingAlgorithm[i] != PRG_ALGO::UNDEFINED) {
            progAlgoCombo->addItem(PRG_ALGO_NAMES[EpromsList[selectedEprom].ProgrammingAlgorithm[i]]);
        }
    }
    progAlgoCombo->setCurrentIndex(0);
    
    sprintf(tmpStr, "%s, VCC: %.2fV, VPP: %.2fV, %srite optimization available", 
            EpromsList[selectedEprom].EpromDescription, EpromsList[selectedEprom].ProgrammingVccVoltage[0], EpromsList[selectedEprom].VppVoltage[0], 
            WriteOptimizationAvailable(EpromsList[selectedEprom]) ? "W" : "No w");
    epromInfoLabel->setText(tmpStr);
    
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].VppVoltage[0]);
    entryVpp->setText(tmpStr);
    
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].ProgrammingVccVoltage[0]);
    entryProgVcc->setText(tmpStr);
    
    sprintf(tmpStr, "Setting %s eprom.\n", EpromsList[selectedEprom].EpromName);
    LogMessage(tmpStr);
    
    if(serialPort->isOpen()) {
        arduinoIO->SelectEprom(selectedEprom);
    }
    
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

void QtGui::ChangeProgrammingAlgorithmSlot(int _index)
{
    extern EPROM EpromsList[];
    char tmpStr[1024];
    
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].VppVoltage[_index]);
    entryVpp->setText(tmpStr);
    
    snprintf(tmpStr, 100, "%.2f", EpromsList[selectedEprom].ProgrammingVccVoltage[_index]);
    entryProgVcc->setText(tmpStr);
}
//----------------------------------------------------------------------
void QtGui::ShowHelpSlot(void)
{
// 1. Crear los textos del contenido
    QLabel *titleLabel = new QLabel(MAKE_STR(APP_NAME) " " APP_VERSION);
    titleLabel->setAlignment(Qt::AlignHCenter);
    titleLabel->setFont(QFont("Arial", 14, QFont::Bold));
    titleLabel->setStyleSheet("color: #ffffff;");

    QLabel *commentLabel = new QLabel(gettext("A graphical interface for Eprom Programmer"));
    commentLabel->setAlignment(Qt::AlignHCenter);
    commentLabel->setStyleSheet("color: #cccccc;");

    QLabel *infoLabel = new QLabel();
    infoLabel->setFont(QFont("Courier", 8));
    infoLabel->setText(
        "Copyright (C) 2021 Ciprian Stingu\n"
        "ciprian stingu at gmail dot com\n"
        "This program is free software; you can\n"
        "redistribute it and/or modify it under\n"
        "the terms of the GNU General Public License\n"
        "as published by the Free Software Foundation;\n"
        "either version 2 of the License, or\n"
        "(at your option) any later version.\n"
        "Modify by armb (c) 2026"
        );
    infoLabel->setAlignment(Qt::AlignHCenter);
    infoLabel->setStyleSheet("color: #aaaaaa;");

// En qtgui.cpp, dentro de ShowHelpSlot:
    QPushButton *licenseButton = new QPushButton();
    licenseButton->setText("License");

// Estilo moderno: fondo gris sutil con bordes redondeados y texto claro
    licenseButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                                 "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(licenseButton, SIGNAL(clicked()), this, SLOT(ShowLicenseWindowSlot()));

    QPushButton *closeButton = new QPushButton();
    closeButton->setText("Close");
    closeButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                               "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(closeButton, SIGNAL(clicked()), this, SLOT(CloseAboutWindowSlot()));

    QHBoxLayout *aboutButtonsLayout = new QHBoxLayout();
    aboutButtonsLayout->setContentsMargins(40, 0, 40, 0);
    aboutButtonsLayout->addWidget(licenseButton);
    aboutButtonsLayout->addSpacing(40);
    aboutButtonsLayout->addWidget(closeButton);

// 2. INSTANCIAR NUESTRA VENTANA PERSONALIZADA UNIVERSAL
    CustomWindow *customAbout = new CustomWindow(gettext("About — Eprom_USB"));
    customAbout->resize(360, 310);

// Vinculamos el puntero global original para que tus otros slots (como cerrar) no fallen
    aboutWindow = customAbout;

// 3. OBTENER EL LAYOUT DE CONTENIDO E INYECTAR LOS WIDGETS
// Este layout pertenece a la zona gris de trabajo (#2d2d2d), abajo de la barra de titulo
    QVBoxLayout *innerLayout = customAbout->getContentLayout();
    innerLayout->addWidget(titleLabel);
    innerLayout->addSpacing(10);
    innerLayout->addWidget(commentLabel);
    innerLayout->addSpacing(15);
    innerLayout->addWidget(infoLabel);
    innerLayout->addSpacing(20);
    innerLayout->addLayout(aboutButtonsLayout);

// Centrar en pantalla
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    int x = (screenGeometry.width() - customAbout->width()) / 2;
    int y = (screenGeometry.height() - customAbout->height()) / 2;
    customAbout->move(x, y);

    DisableButtons();

// Mostrar la ventana
    customAbout->show();
}
//----------------------------------------------------------------------

void QtGui::CloseAboutWindowSlot(void)
{
    aboutWindow->close();
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------
void QtGui::ShowLicenseWindowSlot(void)
{
// === 1. CONTENIDO ORIGINAL DE TU LICENCIA ===
    QTextEdit *licenseBox = new QTextEdit();
    licenseBox->setReadOnly(true);
    licenseBox->setLineWrapMode(QTextEdit::NoWrap);
    licenseBox->setAcceptRichText(false);
    licenseBox->setFontFamily("monospace");
    licenseBox->setFontPointSize(8);
    licenseBox->insertPlainText(
        "This program is free software; you can redistribute it and/or\n"
        "modify it under the terms of the GNU Library General Public License as\n"
        "published by the Free Software Foundation; either version 2 of the\n"
        "License, or (at your option) any later version.\n"
        "\n"
        "This program is distributed in the hope that it will be useful,\n"
        "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
        "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\n"
        "Library General Public License for more details.\n"
        "\n"
        "You should have received a copy of the GNU Library General Public\n"
        "License along with the Gnome Library; see the file COPYING.LIB.  If not,\n"
        "write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,\n"
        "Boston, MA 02111-1307, USA.\n"
        );
    licenseBox->moveCursor(QTextCursor::Start);

    QPushButton *closeButton = new QPushButton();
    closeButton->setText("Close");
    connect(closeButton, SIGNAL(clicked()), this, SLOT(CloseLicenseWindowSlot()));

    QHBoxLayout *licenseButtonLayout = new QHBoxLayout();
    licenseButtonLayout->setAlignment(Qt::AlignRight);
    licenseButtonLayout->addWidget(closeButton);

// === 2. ESTRUCTURA DE LAYOUTS DEL CONTENIDO ===
    QVBoxLayout *licenseLayout = new QVBoxLayout();
    licenseLayout->addWidget(licenseBox);
    licenseLayout->addLayout(licenseButtonLayout);

// === 3. SE VINCULA A NUESTRA VENTANA UNIVERSAL PERSONALIZADA ===
// Cambiamos el QWidget plano por el CustomWindow con el titulo distinguido
    CustomWindow *customLicense = new CustomWindow(gettext("License"));
    customLicense->resize(440, 290); // Escalado un poco en alto por la barra de titulo superior

// Guardamos la referencia en tu puntero global original para que los slots no fallen
    licenseWindow = customLicense;

// Obtenemos el layout de trabajo inyectando los widgets debajo de la cabecera
    QVBoxLayout *innerLayout = customLicense->getContentLayout();
    innerLayout->addLayout(licenseLayout);

// Mover al centro de la pantalla (Tu logica original intacta)
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    int x = (screenGeometry.width() - licenseWindow->width()) / 2;
    int y = (screenGeometry.height() - licenseWindow->height()) / 2;
    licenseWindow->move(x, y);

    licenseWindow->show();
}
//----------------------------------------------------------------------

void QtGui::CloseLicenseWindowSlot(void)
{
    licenseWindow->close();
}
//----------------------------------------------------------------------

void QtGui::LogMessage(const char *data)
{
    logBox->insertPlainText(data);
    logBox->ensureCursorVisible();
}
//----------------------------------------------------------------------

void QtGui::LogMessage(QString data)
{
    logBox->insertPlainText(data);
    logBox->ensureCursorVisible();
}
//----------------------------------------------------------------------

void QtGui::UpdateCursorOnSerialOperationStartSlot(void)
{
    QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
}
//----------------------------------------------------------------------

void QtGui::ShowMessageOnSerialOperationErrorSlot(const char *message)
{
    ShowCustomAlert(QMessageBox::Information, "Serial Port Error", message, QMessageBox::Close);
//    QMessageBox::critical(mainWindow, "Serial port error", message);
}
//----------------------------------------------------------------------

void QtGui::UpdateCursorOnSerialOperationCompleteSlot(void)
{
    QApplication::restoreOverrideCursor();
}
//----------------------------------------------------------------------

void QtGui::EpromOperationProgressBarSlot(int value)
{
    mainProgressBar->setValue(value);
    QCoreApplication::processEvents();
}
//----------------------------------------------------------------------

void QtGui::UpdateVoltageValueSlot(double vccValue, double vppValue)
{
    QObject::disconnect(updateVoltageValueConnection);
    
    QString text;
    text = QString("VCC: %1V").arg(vccValue, 0, 'f', 2);

//    text.sprintf("VCC: %02.2fV", vccValue);
    readVccVoltageLabel->setText(text);
    
    text = QString("VPP: %1V").arg(vppValue, 0, 'f', 2);
//    text.sprintf("VPP: %02.2fV", vppValue);
    readVppVoltageLabel->setText(text);
    
//    text.sprintf("[VCC] %02.2fV, [VPP] %02.2fV\n", vccValue, vppValue);
    text = QString("[VCC] %1V, [VPP] %2V\n").arg(vccValue, 0, 'f', 2).arg(vppValue, 0, 'f', 2);   
    LogMessage(text);
}

//----------------------------------------------------------------------
void QtGui::ShowVoltageSlot(void)
{
    QLabel *readVoltageLabel = new QLabel("Current voltages");
    readVoltageLabel->setAlignment(Qt::AlignHCenter);

// Forzar texto blanco para el titulo interno
    readVoltageLabel->setStyleSheet("color: #ffffff; font-weight: bold;");

    readVccVoltageLabel = new QLabel("VCC: Reading...");
    readVppVoltageLabel = new QLabel("VPP: Reading...");

// Forzar texto gris claro brillante para las lecturas de voltajes
    readVccVoltageLabel->setStyleSheet("color: #e0e0e0; font-size: 13px;");
    readVppVoltageLabel->setStyleSheet("color: #e0e0e0; font-size: 13px;");

    QVBoxLayout *readVoltageLayout = new QVBoxLayout();
    readVoltageLayout->setAlignment(Qt::AlignTop);
    readVoltageLayout->setContentsMargins(50, 10, 50, 25);
    readVoltageLayout->addWidget(readVoltageLabel);
    readVoltageLayout->addSpacing(5);
    readVoltageLayout->addWidget(readVccVoltageLabel);
    readVoltageLayout->addSpacing(5);
    readVoltageLayout->addWidget(readVppVoltageLabel);

// Boton Refresh con estilo oscuro unificado
    QPushButton *refreshButton = new QPushButton();
    refreshButton->setText("Refresh");
    refreshButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                                 "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(refreshButton, SIGNAL(clicked()), this, SLOT(RefresVoltageSlot()));

// Boton Close con estilo oscuro unificado
    QPushButton *closeButton = new QPushButton();
    closeButton->setText("Close");
    closeButton->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; }"
                               "QPushButton:hover { background-color: #4d4d4d; border-color: #777777; }");
    connect(closeButton, SIGNAL(clicked()), this, SLOT(CloseVoltageWindowSlot()));

    QHBoxLayout *readVoltageButtonsLayout = new QHBoxLayout();
    readVoltageButtonsLayout->setContentsMargins(25, 25, 25, 0);
    readVoltageButtonsLayout->addWidget(refreshButton);
    readVoltageButtonsLayout->addSpacing(40);
    readVoltageButtonsLayout->addWidget(closeButton);

    readVoltageLayout->addLayout(readVoltageButtonsLayout);

// === MIGRACIoN DE LA VENTANA A NUESTRA CLASE BASE CUSTOM ===
// Reemplazamos el QWidget tradicional por CustomWindow con titulo e icono unificado
    CustomWindow *customVoltage = new CustomWindow(gettext("Voltage"));
    customVoltage->resize(240, 210); // Escalado sutil para la barra de titulo y dar aire a las lecturas

// Sincronizamos con tu puntero de control original de la clase
    voltageWindow = customVoltage;

// Obtenemos el layout de la zona transparente e inyectamos los elementos de lectura de voltajes
    QVBoxLayout *innerLayout = customVoltage->getContentLayout();
    innerLayout->addLayout(readVoltageLayout);

// Mover al centro de la pantalla (Tu logica original intacta)
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    int x = (screenGeometry.width() - voltageWindow->width()) / 2;
    int y = (screenGeometry.height() - voltageWindow->height()) / 2;
    voltageWindow->move(x, y);

    RefresVoltageSlot();
    DisableButtons();

// Mostrar la ventana terminada
    customVoltage->show();
}
//----------------------------------------------------------------------

void QtGui::CloseVoltageWindowSlot(void)
{
    voltageWindow->close();
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

void QtGui::RefresVoltageSlot(void)
{
    readVccVoltageLabel->setText("VCC: Reading...");
    readVppVoltageLabel->setText("VPP: Reading...");
    updateVoltageValueConnection = QObject::connect(arduinoIO, SIGNAL(VoltageUpdatedSignal(double, double)), this, SLOT(UpdateVoltageValueSlot(double, double)));
    arduinoIO->ReadVoltage();
}
//----------------------------------------------------------------------

void QtGui::HardwareTestSlot(void)
{
    if(selectedEprom != EPROM_TYPE::NONE)
    {
        QMessageBox::critical(mainWindow, "Hardware test", "Please remove any EPROM from socket\nand set the Eprom type to NONE.");
        return;
    }
    
    DisableButtons();
    
    LogMessage("Starting hardware test...\n");
    hardwareTestConnection = QObject::connect(arduinoIO, SIGNAL(HardwareTestStepSignal(const char *)), this, SLOT(HardwareTestStepSlot(const char *)));
    arduinoIO->HardwareTest();
}
//----------------------------------------------------------------------

void QtGui::HardwareTestStepSlot(const char *message)
{
    LogMessage(message);
    
    if(strcmp(arduinoIO->HW_TEST_END, message) == 0) 
    {
        QObject::disconnect(hardwareTestConnection);
        UpdateButtonsStatus();
    }
    
    QCoreApplication::processEvents();
}
//----------------------------------------------------------------------

void QtGui::ReadEpromSlot(void)
{
    extern EPROM EpromsList[];
    
    if(!serialPort->isOpen())
    {

// CAMBIO:: Llamamos a nuestra funcion de alerta oscura unificada
      ShowCustomAlert(QMessageBox::Information, "Serial Port Error", "Connect Eprom Programmer", QMessageBox::Close);
    }
    
    mainProgressBar->setValue(0);
    mainProgressBar->setMaximum(arduinoIO->GetEpromSize());
    LogMessage(QString("Reading %1 bytes from eprom...\n").arg(arduinoIO->GetEpromSize()));
    progressBarConnection = QObject::connect(arduinoIO, SIGNAL(ReadBlockSignal(int)), this, SLOT(EpromOperationProgressBarSlot(int)));
    updateReadDataConnection = QObject::connect(arduinoIO, SIGNAL(ReadEpromDataSignal(int, int, uint8_t *)), this, SLOT(ReadEpromDataSlot(int, int, uint8_t *)));
    checkEpromClearConnection = QObject::connect(arduinoIO, SIGNAL(ReadCompleteSignal()), this, SLOT(CheckEpromClearSlot()));
    epromRead = false;

    DisableButtons();
    
    operationTimer.start();
    
    arduinoIO->ReadEprom();
}
//----------------------------------------------------------------------

void QtGui::CheckEpromClearSlot(void)
{
    QObject::disconnect(checkEpromClearConnection);
    QObject::disconnect(progressBarConnection);
    QObject::disconnect(updateReadDataConnection);
    
    LogMessage(QString("Read in %1 seconds.\n").arg(operationTimer.elapsed() / 1000));
    epromRead = true;
    UpdateButtonsStatus();
    
    uint8_t *dataRead = reinterpret_cast<uint8_t *>(arduinoIO->GetReadBuffer()->data());
    for(int i = 0, j = arduinoIO->GetReadBuffer()->length(); i < j; i++)
    {
        if(dataRead[i] != 0xFF)
        {
            LogMessage("Eprom not clear.\n");
            return;
        }
    }
    LogMessage("Eprom clear.\n");
}
//----------------------------------------------------------------------

void QtGui::DisplayEpromData(uint8_t *buffer, int maxSize, int baseAddr, int currentSize)
{
    char msgStr[1024];
    QString message;
    
	for(int i = baseAddr; i < baseAddr + currentSize && i < maxSize; i += DISPLAY_COLUMNS)
	{
		bool lineIsEmpty = true;
		for(int j = i; j < i + DISPLAY_COLUMNS && j < baseAddr + currentSize && i < maxSize; j++) 
		{
			if(buffer[j] < 0xFF) 
			{
				lineIsEmpty = false;
				break;
			}	
		}
		if(!lineIsEmpty) 
		{
            sprintf(msgStr, "%05X: ", i);
            message.append(msgStr);
			for(int j = i; j < i + DISPLAY_COLUMNS && j < baseAddr + currentSize && i < maxSize; j++) 
            {
				sprintf(msgStr, "%02X%s", buffer[j], j < i + DISPLAY_COLUMNS - 1 ? " " : "");
                message.append(msgStr);
			}
			message.append("\t");
			for(int j = i; j < i + DISPLAY_COLUMNS && j < baseAddr + currentSize && i < maxSize; j++) 
            {
				sprintf(msgStr, "%c", isprint(buffer[j]) && buffer[j] < 0xFF ? buffer[j] : '.');
                message.append(msgStr);
			}
            message.append("\n");
		}
	}
	
	LogMessage(message);
}
//----------------------------------------------------------------------

void QtGui::ReadEpromDataSlot(int address, int size, uint8_t *data)
{
    DisplayEpromData(data, arduinoIO->GetEpromSize(), address, size);
}
//----------------------------------------------------------------------

void QtGui::ResetVariables(void)
{
    epromRead = false;
    epromWritten = false;
    fileLoaded = false;
    mainProgressBar->setValue(0);
    mainProgressBar->setMaximum(100);
}
//----------------------------------------------------------------------

void QtGui::FileSaveSlot(void)
{
    QString fileName = QFileDialog::getSaveFileName(mainWindow, "Save EPROM file", "", "Binary (*.bin);;Rom (*.rom);;All Files (*)");

    if(fileName.isEmpty()) {
        return;
    }
    else
    {
        if(fileName.right(4).indexOf(".bin", 0) == -1 && fileName.right(4).indexOf(".rom", 0) == -1) {
            fileName.append(QString(".bin"));
        }

        QFile file(fileName);
        if(!file.open(QIODevice::WriteOnly))
        {
            QMessageBox::information(mainWindow, "Unable to open file", file.errorString());
            return;
        }

        file.write(*arduinoIO->GetReadBuffer());
        file.close();
        LogMessage(QString("Saving to %1...\n").arg(fileName));
        LogMessage(QString("Written %1 bytes.\n").arg(arduinoIO->GetReadBuffer()->count()));
    }
}
//----------------------------------------------------------------------

void QtGui::FileOpenSlot(void)
{
    QString fileName = QFileDialog::getOpenFileName(mainWindow, "Load EPROM file", "", "Binary (*.bin);;Rom (*.rom);;All Files (*)");

    if(fileName.isEmpty()) {
        return;
    }
    else
    {
        QFile file(fileName);
        if(!file.open(QIODevice::ReadOnly))
        {

// REEMPLAZO PARA ERRORES DINaMICOS DEL PUERTO SERIAL:
            ShowCustomAlert(QMessageBox::Critical, "Unable to open file", file.errorString(), QMessageBox::Close);
            return;
        }

        arduinoIO->GetWriteBuffer()->clear();
        arduinoIO->GetWriteBuffer()->append(file.readAll());

        LogMessage(QString("Loading from %1...\n").arg(fileName));
        LogMessage(QString("Read %1 bytes.\n").arg(arduinoIO->GetWriteBuffer()->count()));
        if (arduinoIO->GetWriteBuffer()->count() < arduinoIO->GetEpromSize())
        {
            LogMessage(QString("Padding by %1 bytes.\n").arg(arduinoIO->GetEpromSize() - arduinoIO->GetWriteBuffer()->count()));
            arduinoIO->GetWriteBuffer()->append((arduinoIO->GetEpromSize() - arduinoIO->GetWriteBuffer()->count()), static_cast<char>(0xFF));
        }
        else if(arduinoIO->GetWriteBuffer()->count() > arduinoIO->GetEpromSize())
        {
            LogMessage(QString("Deleted %1 bytes.\n").arg(arduinoIO->GetWriteBuffer()->count() - arduinoIO->GetEpromSize()));
            arduinoIO->GetWriteBuffer()->resize(arduinoIO->GetEpromSize());
        }
        
        mainProgressBar->setValue(0);
        mainProgressBar->setMaximum(arduinoIO->GetEpromSize());
        uint8_t *fileData = reinterpret_cast<uint8_t *>(arduinoIO->GetWriteBuffer()->data());
        for(int i = 0; i < arduinoIO->GetEpromSize(); i += DISPLAY_COLUMNS * 32) 
        {
            DisplayEpromData(fileData, arduinoIO->GetEpromSize(), i, DISPLAY_COLUMNS * 32);
            EpromOperationProgressBarSlot(i + DISPLAY_COLUMNS * 32);
        }
        
        fileLoaded = true;

        UpdateButtonsStatus();
    }
}
//----------------------------------------------------------------------

void QtGui::WriteEpromSlot(void)
{
    if(!fileLoaded)
    {

// REEMPLAZO PARA ERRORES DINaMICOS DEL PUERTO SERIAL:
        ShowCustomAlert(QMessageBox::Critical, "Write EPROM", "No File Loaded!", QMessageBox::Close);
        return;
    }
    
    extern EPROM EpromsList[];

    mainProgressBar->setValue(0);
    mainProgressBar->setMaximum(arduinoIO->GetEpromSize());
    LogMessage(QString("Writing %1 bytes...").arg(arduinoIO->GetEpromSize()));
    progressBarConnection = QObject::connect(arduinoIO, SIGNAL(WriteBlockSignal(int)), this, SLOT(EpromOperationProgressBarSlot(int)));
    writeCompleteConnection = QObject::connect(arduinoIO, SIGNAL(WriteCompleteSignal(bool, const char *)), this, SLOT(WriteCompleteSlot(bool, const char *)));
    epromRead = false;
    epromWritten = false;
    
    DisableButtons();
    
    operationTimer.start();

    qDebug() << "=== Valores desde la interfaz ===";
    qDebug() << "entryProgVcc texto:" << entryProgVcc->text();
    qDebug() << "entryVpp texto:" << entryVpp->text();
    qDebug() << "VCC convertido:" << entryProgVcc->text().toDouble();
    qDebug() << "VPP convertido:" << entryVpp->text().toDouble();

// Convertir correctamente coma/punto
    QString vccText = entryProgVcc->text().replace(',', '.');
    QString vppText = entryVpp->text().replace(',', '.');

    double vcc = vccText.toDouble();
    double vpp = vppText.toDouble();


    qDebug() << "VCC:" << vcc << " | VPP:" << vpp;

    arduinoIO->WriteEprom(
        vcc,
        vpp,
        EpromsList[selectedEprom].ProgrammingAlgorithm[progAlgoCombo->currentIndex()]
        );
}
//----------------------------------------------------------------------

void QtGui::WriteCompleteSlot(bool successful, const char *message)
{
    QObject::disconnect(writeCompleteConnection);
    QObject::disconnect(progressBarConnection);
    epromWritten = successful;
    
    QString infoMessage = epromWritten ? " complete." : " error.\nMessage: ";
    if(!epromWritten) 
    {
        infoMessage.append(message);
        infoMessage.append("\n");
    }
    else 
    {
        infoMessage.append(QString(" Duration: %1 seconds.\n").arg(operationTimer.elapsed() / 1000));
        infoMessage.append(message);
        infoMessage.append("\n");
    }
    LogMessage(infoMessage);
    
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

bool QtGui::WriteOptimizationAvailable(EPROM eprom)
{
    for(int i = 0; i < PROGRAMMING_ALGORITHMS; i++) 
    {
        if(eprom.ProgrammingAlgorithm[i] != PRG_ALGO::UNDEFINED && eprom.ProgrammingAlgorithm[i] != PRG_ALGO::STANDARD) {
            return true;
        }
    }
    return false;
}
//----------------------------------------------------------------------

void QtGui::VerifyDataSlot(void)
{
    DisableButtons();

    if(arduinoIO->GetReadBuffer()->count())
    {

// CAMBIO:: Llamamos a nuestra funcion de alerta oscura unificada
        int result = ShowCustomAlert(QMessageBox::Question, "Verify", "Re-read eprom?", QMessageBox::Yes | QMessageBox::No);

        if(result == QMessageBox::Yes) {
            ReReadEpromSlot();
        }
        else {
            ContinueVerifyDataSlot();
        }
    }
    else {
        ReReadEpromSlot();
    }
}
//----------------------------------------------------------------------

void QtGui::DisplayDifferences(uint8_t* inBuffer, uint8_t* outBuffer, int offset, int size)
{
    char msgStr[1024];
    QString message;
    
    sprintf(msgStr, "OFFSET: 0x%05X\nFile:  ", offset);
    message.append(msgStr);
	for(int i = offset; i < offset + size; i++) 
    {
		sprintf(msgStr, "%02X%s", inBuffer[i], i == offset + size - 1 ? "" : " ");
        message.append(msgStr);
	}
	message.append("\nEprom: ");
	for(int i = offset; i < offset + size; i++) 
    {
		sprintf(msgStr, "%02X%s", outBuffer[i], i == offset + size - 1 ? "" : " ");
        message.append(msgStr);
	}
	message.append("\n\n");
    LogMessage(message);
}
//----------------------------------------------------------------------

void QtGui::ReReadEpromSlot(void)
{
    extern EPROM EpromsList[];
    
    mainProgressBar->setValue(0);
    mainProgressBar->setMaximum(arduinoIO->GetEpromSize());
    progressBarConnection = QObject::connect(arduinoIO, SIGNAL(ReadBlockSignal(int)), this, SLOT(EpromOperationProgressBarSlot(int)));
    updateReadDataConnection = QObject::connect(arduinoIO, SIGNAL(ReadEpromDataSignal(int, int, uint8_t *)), this, SLOT(ReadEpromDataSlot(int, int, uint8_t *)));
    checkEpromClearConnection = QObject::connect(arduinoIO, SIGNAL(ReadCompleteSignal()), this, SLOT(ContinueVerifyDataSlot()));
    
    arduinoIO->ReadEprom();
}
//----------------------------------------------------------------------

void QtGui::ContinueVerifyDataSlot(void)
{
    QObject::disconnect(checkEpromClearConnection);
    QObject::disconnect(progressBarConnection);
    QObject::disconnect(updateReadDataConnection);
    
    mainProgressBar->setValue(0);
    mainProgressBar->setMaximum(arduinoIO->GetEpromSize());
    uint8_t *fileData = reinterpret_cast<uint8_t *>(arduinoIO->GetWriteBuffer()->data());
    uint8_t *epromData = reinterpret_cast<uint8_t *>(arduinoIO->GetReadBuffer()->data());
    int totalCodeDifferences = 0;
    
    LogMessage("\nCODE COMPARISION RESULT\n\n");
    for(int i = 0; i < arduinoIO->GetEpromSize(); i += DISPLAY_COLUMNS) 
    {
        int differences = 0;
        
        for(int j = 0; j < DISPLAY_COLUMNS; j++)
		{
			if(fileData[i + j] != epromData[i + j]) {
				differences++;
			}
		}
		if(differences > 0) 
		{
			totalCodeDifferences += differences;
			DisplayDifferences(fileData, epromData, i, DISPLAY_COLUMNS);
		}

        EpromOperationProgressBarSlot(i + DISPLAY_COLUMNS);
    }
    
    QString message;
    message.append(QString::number(totalCodeDifferences));
    message.append(" differences found.\n");
    LogMessage(message);
    
    UpdateButtonsStatus();
}
//----------------------------------------------------------------------

int QtGui::ShowCustomAlert(QMessageBox::Icon alertType, const QString &title, const QString &text, QMessageBox::StandardButtons buttons)
{
// 1. Instanciamos nuestra ventana universal con el titulo de la alerta
    CustomWindow *alertWindow = new CustomWindow(title);
    alertWindow->setFixedSize(320, 160);

// 2. Creamos un QLabel para el texto del mensaje y lo forzamos a blanco
    QLabel *messageLabel = new QLabel(text);
    messageLabel->setWordWrap(true);
    messageLabel->setAlignment(Qt::AlignCenter);
    messageLabel->setStyleSheet("color: #ffffff; font-size: 13px;");

// 3. Creamos el contenedor de botones inferiores
    QHBoxLayout *buttonsLayout = new QHBoxLayout();
    buttonsLayout->setAlignment(Qt::AlignCenter);

    int userResult = QMessageBox::No; // Resultado por defecto

// Si la alerta pide boton "Yes" o "OK"
    if (buttons & QMessageBox::Yes || buttons & QMessageBox::Ok) {
        QPushButton *yesBtn = new QPushButton(buttons & QMessageBox::Yes ? "Yes" : "OK");
        yesBtn->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; min-width: 70px; }"
                              "QPushButton:hover { background-color: #4d4d4d; }");
        connect(yesBtn, &QPushButton::clicked, alertWindow, [&, alertWindow]() {
            userResult = QMessageBox::Yes;
            alertWindow->close();
        });
        buttonsLayout->addWidget(yesBtn);
    }

// Si la alerta pide boton "No" o "Close"
    if (buttons & QMessageBox::No || buttons & QMessageBox::Close) {
        if (buttonsLayout->count() > 0) buttonsLayout->addSpacing(20);
        QPushButton *noBtn = new QPushButton(buttons & QMessageBox::No ? "No" : "Close");
        noBtn->setStyleSheet("QPushButton { background-color: #3d3d3d; color: white; border: 1px solid #555555; border-radius: 4px; padding: 5px 15px; min-width: 70px; }"
                             "QPushButton:hover { background-color: #4d4d4d; }");
        connect(noBtn, &QPushButton::clicked, alertWindow, [&, alertWindow]() {
            userResult = QMessageBox::No;
            alertWindow->close();
        });
        buttonsLayout->addWidget(noBtn);
    }

// 4. Armamos el diseño interno dentro de la zona transparente de CustomWindow
    QVBoxLayout *innerLayout = alertWindow->getContentLayout();
    innerLayout->setContentsMargins(15, 10, 15, 10);
    innerLayout->addWidget(messageLabel);

// AGREGAMOS ESTA CONDICIoN: Solo añade el layout de botones si realmente hay alguno
    if (buttons != QMessageBox::NoButton) {
        innerLayout->addSpacing(15);
        innerLayout->addLayout(buttonsLayout);
    } else {
        // Si no hay botones, permitimos que se destruya automaticamente al cerrarla por codigo
        alertWindow->setAttribute(Qt::WA_DeleteOnClose);
    }

// Centrar en pantalla
    QRect screenGeometry = QGuiApplication::screens().first()->geometry();
    alertWindow->move((screenGeometry.width() - alertWindow->width()) / 2,
                      (screenGeometry.height() - alertWindow->height()) / 2);

// Si NO tiene botones, NO la hagas Modal (asi el usuario puede seguir usando la app si es un aviso de progreso)
    if (buttons == QMessageBox::NoButton) {
        alertWindow->setWindowModality(Qt::NonModal);
        alertWindow->show();
        return userResult; // Retorna inmediatamente sin trabar el hilo
    }

// Si TIENE botones, se comporta de forma modal como antes
    alertWindow->setWindowModality(Qt::ApplicationModal);
    alertWindow->setAttribute(Qt::WA_DeleteOnClose);
    alertWindow->show();

    QEventLoop loop;
    QObject::connect(alertWindow, &QWidget::destroyed, &loop, &QEventLoop::quit);
    loop.exec();

    return userResult;
}
